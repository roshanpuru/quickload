package coin.digital.funds.servers.web;

import coin.digital.funds.socket.RealTimeDataSocket;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.websocket.jsr356.server.deploy.WebSocketServerContainerInitializer;

import javax.websocket.server.ServerContainer;

public class WebServerBootStrap {
    private Server jettyServer;

    public void createAndStartJettyServer() {

        try {
            jettyServer = new Server();
            ServerConnector connector = new ServerConnector(jettyServer);
            connector.setPort(54210);
            jettyServer.addConnector(connector);

            ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
            context.setContextPath("/");
            jettyServer.setHandler(context);

            ServerContainer container = WebSocketServerContainerInitializer.configureContext(context);
            container.addEndpoint(RealTimeDataSocket.class);

            jettyServer.start();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
