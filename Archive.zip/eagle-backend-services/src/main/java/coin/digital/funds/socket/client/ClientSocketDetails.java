package coin.digital.funds.socket.client;

public class ClientSocketDetails {
    public static final String GEMINI_WEBSOCKET_MARAKET_DATA_URL = "wss://api.gemini.com/v1/marketdata/btcusd";
}
