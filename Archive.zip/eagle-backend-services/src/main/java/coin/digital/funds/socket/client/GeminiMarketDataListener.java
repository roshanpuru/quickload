package coin.digital.funds.socket.client;

import org.eclipse.jetty.websocket.api.annotations.OnWebSocketClose;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;


import java.util.concurrent.CountDownLatch;
import java.util.logging.Logger;


import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import org.eclipse.jetty.websocket.api.Session;
import java.util.concurrent.TimeUnit;



@WebSocket(maxTextMessageSize = 1024 * 1024)
public class GeminiMarketDataListener {

    private Logger logger = Logger.getLogger(this.getClass().getName());
    private final CountDownLatch closeLatch;
    private Session session;

    public GeminiMarketDataListener() {
        this.closeLatch = new CountDownLatch(1);
    }
    public boolean awaitClose(int duration, TimeUnit unit) throws InterruptedException
    {
        return this.closeLatch.await(duration,unit);
    }

    @OnWebSocketConnect
    public void onConnect(Session session) {
        System.out.printf("Got connect: %s%n",session);
        this.session = session;
    }

    @OnWebSocketMessage
    public void onMessage(String message) {
        System.out.printf("Got msg: %s%n",message);
    }

    @OnWebSocketClose
    public void onClose(int statusCode, String reason) {
        System.out.printf("Connection closed: %d - %s%n",statusCode,reason);
        this.session = null;
        this.closeLatch.countDown(); // trigger latch
    }


}