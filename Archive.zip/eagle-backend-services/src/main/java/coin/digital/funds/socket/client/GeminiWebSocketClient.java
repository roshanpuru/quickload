package coin.digital.funds.socket.client;

import org.eclipse.jetty.io.ssl.ALPNProcessor;


import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.TimeUnit;
import org.eclipse.jetty.websocket.client.ClientUpgradeRequest;
import org.eclipse.jetty.websocket.client.WebSocketClient;


public class GeminiWebSocketClient {

    private Logger logger = Logger.getLogger(this.getClass().getName());

    public static void startListener(){
            WebSocketClient client = new WebSocketClient();
            GeminiMarketDataListener socket = new GeminiMarketDataListener();

        try {
            client.start();
            ClientUpgradeRequest request = new ClientUpgradeRequest();
            System.out.println("Connecting to " + ClientSocketDetails.GEMINI_WEBSOCKET_MARAKET_DATA_URL);
            client.connect(socket, URI.create(ClientSocketDetails.GEMINI_WEBSOCKET_MARAKET_DATA_URL));
            socket.awaitClose(5,TimeUnit.SECONDS);

        } catch (Exception exception ) {
            Logger.getLogger(ALPNProcessor.Client.class.getName()).log(Level.SEVERE, null, exception);
        }
    }
}