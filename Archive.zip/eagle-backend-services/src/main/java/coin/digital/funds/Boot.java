package coin.digital.funds;

import coin.digital.funds.servers.web.WebServerBootStrap;

public class Boot {

    public static void main(String[] program_arguments){
        new WebServerBootStrap().createAndStartJettyServer();
    }

}
