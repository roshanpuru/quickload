package coin.digital.funds.socket;

import coin.digital.funds.socket.client.GeminiWebSocketClient;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;

@WebSocket
@ServerEndpoint(value="/communicate/")
public class RealTimeDataSocket {

    @OnOpen
    public void onWebSocketConnect(Session session, EndpointConfig endpointConfig) throws Exception{
        System.out.println("Good work done");
        GeminiWebSocketClient.startListener();
    }

    @OnMessage
    public void onWebSocketText(String message, Session session) throws Exception{

    }

    @OnClose
    public void onWebSocketClose(CloseReason reason, Session session){

    }

    @OnError
    public void onWebSocketError(Throwable cause){
        cause.printStackTrace();
    }
}
