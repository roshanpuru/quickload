import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';
import { NgxCarouselModule } from 'ngx-carousel';
import 'hammerjs';
import { Api, Settings, User } from '../providers/providers';

import { AppComponent } from './app.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { FundComponent } from './fund/fund.component';
import { MessageService } from './services/MessageServices/MessageService';
import { ServerSocket } from './services/SocketServices/WebSocketClientServices';
import { LoginComponent } from './login/login.component';

import { LoginService } from '../providers/login/login.service';
import { Principal } from '../providers/auth/principal.service';
import { AccountService } from '../providers/auth/account.service';
import { AuthServerProvider } from '../providers/auth/auth-jwt.service';
import { AuthInterceptor } from '../providers/auth/auth-interceptor';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { FlashMessagesModule } from 'ngx-flash-messages';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {MatAutocompleteModule, MatInputModule} from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    UserProfileComponent,
    FundComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    NgxCarouselModule,
    CommonModule,
    BrowserAnimationsModule, 
    FlashMessagesModule,  
    NoopAnimationsModule,
    MatAutocompleteModule,  
    MatInputModule,
    ReactiveFormsModule,
  ],
  providers: [MessageService,ServerSocket,Api,
    User,
    LoginService,
    Principal,
    AccountService,
    AuthServerProvider,
    HttpClientModule,
    LocalStorageService,
    SessionStorageService,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
