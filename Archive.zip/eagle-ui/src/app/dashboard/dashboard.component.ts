import { Component, OnInit } from '@angular/core';
import { MessageService } from 'app/services/MessageServices/MessageService';
import { Subscription } from 'rxjs/Subscription';
import { ServerSocket } from 'app/services/SocketServices/WebSocketClientServices';
import {MatAutocompleteModule,MatAutocomplete} from '@angular/material/autocomplete';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  private socketSubscription: Subscription;
  loginScreen : boolean = true;
  searchScreen: boolean = false;
  constructor(private messageService: MessageService, private socket: ServerSocket ) { }
  ngOnInit() {
    this.socket.connect();
    this.socketSubscription = this.socket.messages.subscribe(message =>{
      //this.messageService.sendMessage()
    });
  }

  ngOnDestroy(){
    this.socketSubscription.unsubscribe();
  }

  onNotify(message:boolean):void {
    this.loginScreen= false;
    this.searchScreen = true;
  }

}
