export class SocketRequestModel{
    constructor(
        public messageId: number,
        public command: string,
        public payload: string
    ){}
}