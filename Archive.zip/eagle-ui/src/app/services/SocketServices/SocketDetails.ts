export class SocketDetails{
        public SOCKET_HOST: string ="127.0.0.1";
        public SOCKET_PORT: string ="54210";
        public SOCKET_PROTOCOL: string ="ws://"
        public SOCKET_END_POINT: string ="/communicate/";
}