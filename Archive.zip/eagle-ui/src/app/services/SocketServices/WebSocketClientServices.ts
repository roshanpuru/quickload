import { QueueingSubject } from 'queueing-subject'
import websocketConnect from 'rxjs-websockets'
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/share';
import { SocketDetails } from '../SocketServices/SocketDetails';

@Injectable()
export class ServerSocket{
    private inputStream: QueueingSubject<string>;
    public messages: Observable<string>;

    public connect(){
        if(this.messages)
            return;   
        let socketDetails = new SocketDetails();
        console.log(socketDetails.SOCKET_PROTOCOL+socketDetails.SOCKET_HOST+ ":" + 
        socketDetails.SOCKET_PORT+ socketDetails.SOCKET_END_POINT);
        
        this.messages = websocketConnect(socketDetails.SOCKET_PROTOCOL+socketDetails.SOCKET_HOST+ ":" + 
                        socketDetails.SOCKET_PORT+ socketDetails.SOCKET_END_POINT,
        this.inputStream = new QueueingSubject<string>()).messages.share();
    }

    public send(message: string){
        this.inputStream.next(message);
    }
}