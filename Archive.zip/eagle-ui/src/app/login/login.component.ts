import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';
import { User } from '../../providers/providers';
import { LoginService } from '../../providers/login/login.service';
import { FlashMessagesService } from 'ngx-flash-messages';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})


export class LoginComponent implements OnInit {
  @Output() notify: EventEmitter<boolean> = new EventEmitter<boolean>();

  account: { login: string, email: string, firstName: string, lastName: string, password: string, langKey: string } = {
    login: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    langKey: 'en'
  };
  
  // Our translated text strings
  private signupErrorString: string;
  private signupSuccessString: string;
  private existingUserError: string;
  private invalidPasswordError: string;
  
  constructor(public flashMessagesService: FlashMessagesService,public user: User, public loginService: LoginService) {}

  ngOnInit() {}

  public registration_form(){
    console.log("Login Form toggle ..");
  }

  doSignup() {
    console.log(this.account);    // set login to same as email
    this.account.login = this.account.email;
    // Attempt to login in through our User service
    this.user.signup(this.account).subscribe(() => {
      alert("registration successfully done");
    }, (response) => {
      // Unable to sign up
      const error = JSON.parse(response.error);
      let displayError = this.signupErrorString;
      if (response.status === 400 && error.type.includes('already-used')) {
          displayError = this.existingUserError;
      } else if (response.status === 400 && error.message === 'error.validation'
          && error.fieldErrors[0].field === 'password' && error.fieldErrors[0].message === 'Size') {
          displayError = this.invalidPasswordError;
      }
    });
  }
  
    // Attempt to login in through our User service
    doLogin() {
      var credentials : any = {};
      credentials.username = this.account.email;
      credentials.password = this.account.password;
      this.loginService.login(credentials, this.toastCall.bind(this)
      ).then((response) => {
      }, (err) => {
        // Unable to log in
        alert('login failed');
        this.account.password = '';

      });
    }
    toastCall(){
      this.flashMessagesService.show('Login Successfull!', {
        classes: ['alert', 'alert-warning'], // You can pass as many classes as you need
        timeout: 3000, // Default is 3000
      });
      this.notify.emit(true);
    }
}
